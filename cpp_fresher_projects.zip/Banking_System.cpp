#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct Account {
    int acc_no;
    char name[100];
    float balance;
};

void createAccount() {
    Account acc;
    cout << "Enter account number: "; cin >> acc.acc_no;
    cout << "Enter name: "; cin.ignore(); cin.getline(acc.name, 100);
    cout << "Enter initial balance: "; cin >> acc.balance;

    ofstream file("accounts.dat", ios::binary | ios::app);
    file.write((char*)&acc, sizeof(acc));
    file.close();
    cout << "Account created!\n";
}

void showAccounts() {
    Account acc;
    ifstream file("accounts.dat", ios::binary);
    while (file.read((char*)&acc, sizeof(acc))) {
        cout << "Account No: " << acc.acc_no << "\nName: " << acc.name << "\nBalance: " << acc.balance << "\n\n";
    }
    file.close();
}

int main() {
    int choice;
    while (true) {
        cout << "1. Create Account\n2. Show All Accounts\n3. Exit\nChoice: ";
        cin >> choice;
        if (choice == 1) createAccount();
        else if (choice == 2) showAccounts();
        else break;
    }
    return 0;
}
