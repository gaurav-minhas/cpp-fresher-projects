#include <iostream>
#include <vector>
using namespace std;

class Student {
public:
    string name;
    int marks[3];
    float average;

    void input() {
        cout << "Enter name: ";
        cin >> name;
        cout << "Enter 3 subject marks: ";
        int sum = 0;
        for (int i = 0; i < 3; i++) {
            cin >> marks[i];
            sum += marks[i];
        }
        average = sum / 3.0;
    }

    void display() {
        cout << "Name: " << name << "\nAverage Marks: " << average << "\nGrade: ";
        if (average >= 90) cout << "A\n";
        else if (average >= 75) cout << "B\n";
        else if (average >= 60) cout << "C\n";
        else cout << "D\n";
    }
};

int main() {
    vector<Student> students;
    int n;
    cout << "Enter number of students: ";
    cin >> n;
    for (int i = 0; i < n; i++) {
        Student s;
        s.input();
        students.push_back(s);
    }
    for (Student s : students) {
        s.display();
    }
    return 0;
}
