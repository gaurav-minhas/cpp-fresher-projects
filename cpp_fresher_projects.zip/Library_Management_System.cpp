#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Book {
public:
    int id;
    string title, author;
    void input() {
        cout << "Enter ID: "; cin >> id;
        cout << "Enter Title: "; cin.ignore(); getline(cin, title);
        cout << "Enter Author: "; getline(cin, author);
    }

    void display() {
        cout << "ID: " << id << "\nTitle: " << title << "\nAuthor: " << author << "\n\n";
    }
};

void addBook() {
    ofstream file("library.txt", ios::app);
    Book b;
    b.input();
    file.write((char*)&b, sizeof(b));
    file.close();
    cout << "Book added!\n";
}

void viewBooks() {
    ifstream file("library.txt");
    Book b;
    while (file.read((char*)&b, sizeof(b))) {
        b.display();
    }
    file.close();
}

int main() {
    int choice;
    while (1) {
        cout << "1. Add Book\n2. View Books\n3. Exit\nChoice: ";
        cin >> choice;
        if (choice == 1) addBook();
        else if (choice == 2) viewBooks();
        else break;
    }
    return 0;
}
