#include <iostream>
using namespace std;

char board[3][3] = { {'1','2','3'}, {'4','5','6'}, {'7','8','9'} };

void displayBoard() {
    cout << "\n";
    for (int i = 0; i < 3; i++) {
        cout << " ";
        for (int j = 0; j < 3; j++) {
            cout << board[i][j];
            if (j < 2) cout << " | ";
        }
        if (i < 2) cout << "\n---|---|---\n";
    }
    cout << "\n";
}

bool checkWin() {
    for (int i = 0; i < 3; i++)
        if ((board[i][0] == board[i][1] && board[i][1] == board[i][2]) ||
            (board[0][i] == board[1][i] && board[1][i] == board[2][i]))
            return true;
    if ((board[0][0] == board[1][1] && board[1][1] == board[2][2]) ||
        (board[0][2] == board[1][1] && board[1][1] == board[2][0]))
        return true;
    return false;
}

void makeMove(int pos, char mark) {
    int row = (pos - 1) / 3, col = (pos - 1) % 3;
    board[row][col] = mark;
}

bool isDraw() {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (board[i][j] != 'X' && board[i][j] != 'O')
                return false;
    return true;
}

int main() {
    int pos, turn = 0;
    char playerMark;
    displayBoard();
    while (true) {
        playerMark = (turn % 2 == 0) ? 'X' : 'O';
        cout << "Player " << playerMark << ", enter position: ";
        cin >> pos;
        makeMove(pos, playerMark);
        displayBoard();
        if (checkWin()) {
            cout << "Player " << playerMark << " wins!\n";
            break;
        }
        if (isDraw()) {
            cout << "It's a draw!\n";
            break;
        }
        turn++;
    }
    return 0;
}
